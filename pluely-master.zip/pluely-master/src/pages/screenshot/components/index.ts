export * from "./ScreenshotConfigs";
